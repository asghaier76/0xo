(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>\n      Ionic Blank\n    </ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n\n<ion-content>\n\n    <div text-center padding>\n        \n        <h1  style=\"color: #3880ff\">0xO Access Crypto in a wink ;)</h1>\n        <h4  style=\"color: #3880ff\">Powered by Torus & 0x</h4>\n\n    </div>\n\n    <ion-card class=\"frontheader animated bounceInUp\">\n        <ion-item>\n              <ion-icon color=\"primary\" name=\"wallet\"></ion-icon>\n\n\n            <ion-label>{{address}}</ion-label>\n              <ion-chip slot=\"end\" >\n                  <ion-label style=\"margin-right: 8px;\">{{balance | number:'1.3-3'}} ETH</ion-label> \n                  <br>\n                  <!-- <ion-avatar class=\"image-center\">\n                      <img src=\"./assets/icon/favicon.png\">\n                  </ion-avatar>  -->\n              </ion-chip>\n        </ion-item>\n\n    </ion-card>\n\n    <ion-card padding>\n        <br>      \n        <ion-item>\n          <span item-start>\n            <ion-icon color=\"primary\" name=\"at\"></ion-icon>\n            </span>\n            <ion-input type=\"text\" placeholder=\"RECIPIENT EMAIL ADDRESS\" [(ngModel)]=\"emailRx\"></ion-input>\n            <button clear item-right (click)=\"resolveEmail()\"><ion-icon color=\"primary\" name=\"search\"></ion-icon></button>\n        </ion-item>\n        <ion-item>\n          <span item-start>\n            </span>\n            <ion-input type=\"text\" placeholder=\"ETHEREUM ADDRESS\" [(ngModel)]=\"addressRx\"></ion-input>\n        </ion-item>\n        <ion-item>\n              <span item-start>\n                  \n              </span>\n              <ion-input type=\"number\" placeholder=\"AMOUNT IN ETH\" [(ngModel)]=\"amount\"></ion-input>\n        </ion-item>\n          \n          <div padding text-center>\n            <ion-button class=\"nxtstpbtn\" color=\"primary\" shape=\"round\" (click)=\"sendETH()\"><ion-icon name=\"send\"></ion-icon>SEND</ion-button>\n          </div>    \n    </ion-card>\n\n    <ion-grid class=\"catgrid animated zoomIn\">\n\n        <ion-row class=\"cat-rows\">\n            <ion-col col-6 class=\"cat-box\" >\n              <div padding text-center>\n                  <ion-button class=\"nxtstpbtn\" color=\"primary\" shape=\"round\" (click)=\"launch0x()\">Tokens</ion-button>\n              </div> \n            </ion-col>\n            <ion-col col-6 class=\"cat-box\">\n              <div padding text-center>\n                <ion-button class=\"nxtstpbtn\" color=\"primary\" shape=\"round\" (click)=\"showWallet()\">Wallet</ion-button>\n              </div> \n            </ion-col>\n        </ion-row>\n      \n      </ion-grid>\n\n\n      <ion-fab class=\"show-xs-up hide-md-up\" slot=\"fixed\" vertical=\"bottom\" horizontal=\"end\">\n        <ion-fab-button (click)=\"signout()\">\n          <ion-icon name=\"log-out\"></ion-icon>\n        </ion-fab-button>\n      </ion-fab>\n  \n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







// import { SharedModule } from '../shared.module';
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                // SharedModule,
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-card {\n  border-radius: 25px 25px 25px 25px !important;\n  margin-top: 20px !important;\n  --background: linear-gradient(95deg, #e0ebff 0%, #eff6fa 100%);\n}\nion-card ion-item {\n  background-color: transparent !important;\n  padding-top: 0px !important;\n}\nion-card ion-item h3 {\n  background-color: transparent !important;\n  margin: 0 !important;\n  color: white !important;\n  font-size: 14px;\n  box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.08);\n}\nion-card ion-item h2 {\n  background-color: transparent !important;\n  margin: 0 !important;\n  color: white !important;\n  font-size: 14px;\n  box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.08);\n}\nion-card ion-item p {\n  color: #3880ff !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hc2doYWllci9Eb2N1bWVudHMvdG9ydXN0ZXN0L3NyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLDZDQUFBO0VBQ0EsMkJBQUE7RUFDQSw4REFBQTtBQ0FKO0FERUk7RUFDVyx3Q0FBQTtFQUNBLDJCQUFBO0FDQWY7QURFZTtFQUNJLHdDQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSwyQ0FBQTtBQ0FuQjtBREVlO0VBQ0ksd0NBQUE7RUFDQSxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLDJDQUFBO0FDQW5CO0FER2U7RUFDRyx5QkFBQTtBQ0RsQiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbmlvbi1jYXJke1xuICAgIGJvcmRlci1yYWRpdXM6IDI1cHggMjVweCAyNXB4IDI1cHggIWltcG9ydGFudDtcbiAgICBtYXJnaW4tdG9wOiAyMHB4ICFpbXBvcnRhbnQ7XG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTVkZWcsICNlMGViZmYgMCUsICNlZmY2ZmEgMTAwJSk7XG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoMjI1ZGVnLCAjZGRjMzRlIDAlLCAjZjBkNTVmIDUlLCAgI2ZiZTE1MCAxMDAlKTtcbiAgICBpb24taXRlbXtcbiAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50IWltcG9ydGFudDtcbiAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcbiAgIFxuICAgICAgICAgICAgICAgaDN7XG4gICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwcHggMXB4IDFweCByZ2JhKDAsMCwwLDAuMDgpO1xuICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgaDJ7XG4gICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwcHggMXB4IDFweCByZ2JhKDAsMCwwLDAuMDgpO1xuICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICBwIHtcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMzg4MGZmICFpbXBvcnRhbnRcbiAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgIH1cbiAgICB9IiwiaW9uLWNhcmQge1xuICBib3JkZXItcmFkaXVzOiAyNXB4IDI1cHggMjVweCAyNXB4ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi10b3A6IDIwcHggIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTVkZWcsICNlMGViZmYgMCUsICNlZmY2ZmEgMTAwJSk7XG59XG5pb24tY2FyZCBpb24taXRlbSB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcbn1cbmlvbi1jYXJkIGlvbi1pdGVtIGgzIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJveC1zaGFkb3c6IDBweCAxcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4wOCk7XG59XG5pb24tY2FyZCBpb24taXRlbSBoMiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBib3gtc2hhZG93OiAwcHggMXB4IDFweCByZ2JhKDAsIDAsIDAsIDAuMDgpO1xufVxuaW9uLWNhcmQgaW9uLWl0ZW0gcCB7XG4gIGNvbG9yOiAjMzg4MGZmICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! web3 */ "./node_modules/web3/src/index.js");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wallet_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../wallet.service */ "./src/app/wallet.service.ts");
/* harmony import */ var _zerox_zerox_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../zerox/zerox.page */ "./src/app/zerox/zerox.page.ts");




// import Torus from "@toruslabs/torus-embed";


var HomePage = /** @class */ (function () {
    function HomePage(wallet, navCtrl, modalCtrl) {
        this.wallet = wallet;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.web3 = {};
        this.torus = this.wallet.torus;
        this.address = this.wallet.account;
        this.web3 = new web3__WEBPACK_IMPORTED_MODULE_3___default.a(this.torus.provider);
        this.zeroXprovider = this.web3.currentProvider;
    }
    HomePage.prototype.ngOnInit = function () {
        var _this = this;
        this.web3.eth.getAccounts().then(function (accounts) {
            _this.web3.eth.getBalance(accounts[0]).then(function (res) {
                console.log('bal ' + res);
                _this.balance = res / Math.pow(10, 18);
                _this.addressTx = accounts[0];
                console.log("acc: " + _this.wallet.account + ", bal: " + _this.balance);
            });
        });
        //this.getUserInfo();
    };
    HomePage.prototype.getUserInfo = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a, _b;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_c) {
                switch (_c.label) {
                    case 0:
                        _b = (_a = console).log;
                        return [4 /*yield*/, this.torus.getUserInfo(true)];
                    case 1:
                        _b.apply(_a, [_c.sent()]);
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.prototype.back = function () {
        console.log("back");
    };
    HomePage.prototype.resolveEmail = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        console.log("email");
                        if (!this.emailRx) return [3 /*break*/, 2];
                        _a = this;
                        return [4 /*yield*/, this.torus.getPublicAddress(this.emailRx)];
                    case 1:
                        _a.addressRx = _b.sent();
                        console.log(this.addressRx);
                        _b.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    HomePage.prototype.sendETH = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                console.log("send");
                if (this.addressRx && this.amount)
                    this.torus.web3.eth.sendTransaction({
                        from: this.addressTx,
                        to: this.addressRx,
                        value: this.amount
                    }, function (err, transactionHash) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(transactionHash);
                        }
                    });
                else
                    alert('Please specify an Ethereum address and the amount first.');
                return [2 /*return*/];
            });
        });
    };
    // async toruslogin() {
    //   try {
    //     this.torus = new Torus();
    //     const t = new Torus();
    //     await this.torus.init(); 
    //     this.torus.login()
    //     .then(res => {
    //       console.log(res);
    //       const web3 = new Web3(this.torus.provider);
    //       this.zeroXprovider = web3.currentProvider;
    //       // arbitrary data
    //       // web3.eth.getAccounts().then(accounts => {
    //       //   let publicAddress = accounts[0]
    //       //   web3.eth.getBalance(accounts[0]).then(console.log)
    //       // });
    //     })
    //     // await this.torus.login(); // await torus.ethereum.enable()
    //     // window.torus = torus
    //   } catch (error) {
    //     console.error(error);
    //   }
    // }
    HomePage.prototype.showButton = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                // console.log(await this.torus.getPublicAddress("asghaier76@gmail.com"));
                this.getUserInfo();
                return [2 /*return*/];
            });
        });
    };
    HomePage.prototype.showWallet = function () {
        this.torus.showWallet(false);
    };
    HomePage.prototype.launch0x = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _zerox_zerox_page__WEBPACK_IMPORTED_MODULE_5__["ZeroxPage"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.prototype.launch0xO = function () {
        var provider = this.zeroXprovider;
        // create ledger instance
        zeroExInstant.render({
            orderSource: 'https://api.radarrelay.com/0x/v2/',
            provider: provider,
            walletDisplayName: '0xO',
            affiliateInfo: {
                feeRecipient: '0x57328ec619d9d6c2b0428472d1cebaf3cf6b8f5d',
                feePercentage: 0.025
            },
            networkId: 1
        }, 'body');
    };
    HomePage.prototype.signout = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.torus.logout()];
                    case 1:
                        _a.sent();
                        this.navCtrl.navigateRoot('/login');
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.ctorParameters = function () { return [
        { type: _wallet_service__WEBPACK_IMPORTED_MODULE_4__["WalletService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_wallet_service__WEBPACK_IMPORTED_MODULE_4__["WalletService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map